import React from 'react';
import { motion } from 'framer-motion';

const brands = [
  "Google", "Apple", "Amazon", "Microsoft", "Tesla", "Spotify", "Airbnb", "Uber", "Netflix", "Adobe"
];

const Marquee = () => {
  return (
    <section className="py-16 bg-black text-white overflow-hidden">
      <div className="mb-8 text-center">
        <motion.h2 
          className="text-2xl md:text-3xl font-bold"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          Trusted by leading brands worldwide
        </motion.h2>
      </div>
      
      <div className="relative flex overflow-x-hidden">
        <div className="animate-marquee whitespace-nowrap flex items-center">
          {brands.map((brand, index) => (
            <div key={index} className="mx-8 text-2xl md:text-4xl font-bold opacity-70 hover:opacity-100 transition-opacity duration-300">
              {brand}
            </div>
          ))}
        </div>
        
        <div className="absolute top-0 animate-marquee2 whitespace-nowrap flex items-center">
          {brands.map((brand, index) => (
            <div key={index} className="mx-8 text-2xl md:text-4xl font-bold opacity-70 hover:opacity-100 transition-opacity duration-300">
              {brand}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Marquee;