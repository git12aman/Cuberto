import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import { Button } from './ui/button';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeLink, setActiveLink] = useState('');

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
    if (!isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
  };

  const navVariants = {
    hidden: { opacity: 0, y: -20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.5,
        ease: "easeInOut"
      }
    }
  };

  const menuVariants = {
    closed: {
      opacity: 0,
      height: 0,
      transition: {
        duration: 0.5,
        ease: "easeInOut",
        staggerChildren: 0.1,
        staggerDirection: -1
      }
    },
    open: {
      opacity: 1,
      height: "100vh",
      transition: {
        duration: 0.5,
        ease: "easeInOut",
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const linkVariants = {
    closed: {
      opacity: 0,
      y: 20
    },
    open: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
        ease: "easeInOut"
      }
    }
  };

  const navLinks = [
    { name: 'Work', href: '#' },
    { name: 'Services', href: '#' },
    { name: 'About', href: '#' },
    { name: 'Insights', href: '#' },
    { name: 'Contact', href: '#' }
  ];

  return (
    <>
      <motion.nav
        initial="hidden"
        animate="visible"
        variants={navVariants}
        className={`fixed top-0 left-0 right-0 z-50 px-6 py-4 md:px-12 transition-all duration-500 ${
          isScrolled ? 'bg-white shadow-md' : 'bg-transparent'
        }`}
      >
        <div className="flex items-center justify-between">
          <motion.div 
            className="text-2xl font-bold"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Cuberto
          </motion.div>
          
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <motion.div
                key={link.name}
                className="relative"
                onHoverStart={() => setActiveLink(link.name)}
                onHoverEnd={() => setActiveLink('')}
              >
                <motion.a 
                  href={link.href} 
                  className={`text-black hover:text-accent transition-colors duration-300 py-2 px-1 relative`}
                  whileHover={{ scale: 1.1 }}
                >
                  {link.name}
                  <AnimatePresence>
                    {activeLink === link.name && (
                      <motion.div
                        className="absolute bottom-0 left-0 right-0 h-0.5 bg-accent"
                        initial={{ width: 0, left: "50%", right: "50%" }}
                        animate={{ width: "100%", left: 0, right: 0 }}
                        exit={{ width: 0, left: "50%", right: "50%" }}
                        transition={{ duration: 0.3 }}
                      />
                    )}
                  </AnimatePresence>
                </motion.a>
              </motion.div>
            ))}
          </div>
          
          <div className="hidden md:block">
            <Button 
              variant="cuberto"
              className="overflow-hidden group relative"
            >
              <motion.span
                className="relative z-10 group-hover:text-white transition-colors duration-300"
                whileHover={{ scale: 1.05 }}
              >
                Get in touch
              </motion.span>
              <motion.div
                className="absolute inset-0 bg-accent"
                initial={{ x: "-100%" }}
                whileHover={{ x: 0 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
              />
            </Button>
          </div>
          
          <motion.button 
            className="md:hidden text-black"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={toggleMenu}
          >
            <AnimatePresence mode="wait">
              {isMenuOpen ? (
                <motion.div
                  key="close"
                  initial={{ rotate: -90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: 90, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <X size={24} />
                </motion.div>
              ) : (
                <motion.div
                  key="menu"
                  initial={{ rotate: 90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: -90, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <Menu size={24} />
                </motion.div>
              )}
            </AnimatePresence>
          </motion.button>
        </div>
      </motion.nav>
      
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial="closed"
            animate="open"
            exit="closed"
            variants={menuVariants}
            className="fixed inset-0 bg-white z-40 pt-20 px-6 overflow-hidden"
          >
            <div className="flex flex-col space-y-6 pt-10">
              {navLinks.map((link, index) => (
                <motion.a 
                  key={link.name}
                  href={link.href} 
                  className="text-3xl font-bold text-black overflow-hidden"
                  variants={linkVariants}
                  custom={index}
                  whileHover={{ x: 20, color: "#ff5c00" }}
                  onClick={() => setIsMenuOpen(false)}
                >
                  <motion.div
                    initial={{ y: 80 }}
                    animate={{ y: 0 }}
                    transition={{ 
                      duration: 0.8,
                      delay: index * 0.1,
                      ease: [0.6, 0.01, -0.05, 0.9]
                    }}
                  >
                    {link.name}
                  </motion.div>
                </motion.a>
              ))}
              <motion.div variants={linkVariants} className="pt-6">
                <Button 
                  variant="cuberto" 
                  className="w-full py-4 overflow-hidden relative group"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <motion.span
                    className="relative z-10 group-hover:text-white transition-colors duration-300"
                  >
                    Get in touch
                  </motion.span>
                  <motion.div
                    className="absolute inset-0 bg-accent"
                    initial={{ x: "-100%" }}
                    whileHover={{ x: 0 }}
                    transition={{ duration: 0.3, ease: "easeInOut" }}
                  />
                </Button>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Navbar;