import React from 'react';
import { motion } from 'framer-motion';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-black text-white py-16 px-6 md:px-12">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="md:col-span-2">
            <motion.div 
              className="text-3xl font-bold mb-6"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Cuberto
            </motion.div>
            <p className="text-gray-400 max-w-md">
              We create award-winning websites, remarkable brands and cutting-edge apps.
            </p>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-6">Navigation</h3>
            <ul className="space-y-3">
              <li>
                <motion.a 
                  href="#" 
                  className="text-gray-400 hover:text-white transition-colors"
                  whileHover={{ x: 5 }}
                >
                  Work
                </motion.a>
              </li>
              <li>
                <motion.a 
                  href="#" 
                  className="text-gray-400 hover:text-white transition-colors"
                  whileHover={{ x: 5 }}
                >
                  Services
                </motion.a>
              </li>
              <li>
                <motion.a 
                  href="#" 
                  className="text-gray-400 hover:text-white transition-colors"
                  whileHover={{ x: 5 }}
                >
                  About
                </motion.a>
              </li>
              <li>
                <motion.a 
                  href="#" 
                  className="text-gray-400 hover:text-white transition-colors"
                  whileHover={{ x: 5 }}
                >
                  Insights
                </motion.a>
              </li>
              <li>
                <motion.a 
                  href="#" 
                  className="text-gray-400 hover:text-white transition-colors"
                  whileHover={{ x: 5 }}
                >
                  Contact
                </motion.a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-6">Contact</h3>
            <ul className="space-y-3">
              <li className="text-gray-400">
                hello@cuberto.com
              </li>
              <li className="text-gray-400">
                +1 (555) 123-4567
              </li>
              <li className="text-gray-400">
                123 Design Street<br />
                Creative District<br />
                New York, NY 10001
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="text-gray-500 mb-4 md:mb-0">
            © {currentYear} Cuberto. All rights reserved.
          </div>
          
          <div className="flex space-x-6">
            <motion.a 
              href="#" 
              className="text-gray-500 hover:text-white transition-colors"
              whileHover={{ y: -3 }}
            >
              Facebook
            </motion.a>
            <motion.a 
              href="#" 
              className="text-gray-500 hover:text-white transition-colors"
              whileHover={{ y: -3 }}
            >
              Instagram
            </motion.a>
            <motion.a 
              href="#" 
              className="text-gray-500 hover:text-white transition-colors"
              whileHover={{ y: -3 }}
            >
              Twitter
            </motion.a>
            <motion.a 
              href="#" 
              className="text-gray-500 hover:text-white transition-colors"
              whileHover={{ y: -3 }}
            >
              LinkedIn
            </motion.a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;