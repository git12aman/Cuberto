import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

const Cursor = () => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [cursorVariant, setCursorVariant] = useState('default');
  const [cursorText, setCursorText] = useState('');
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const mouseMove = (e: MouseEvent) => {
      setMousePosition({
        x: e.clientX,
        y: e.clientY
      });
      
      if (!isVisible) {
        setIsVisible(true);
      }
    };

    const mouseLeave = () => {
      setIsVisible(false);
    };

    const mouseEnter = () => {
      setIsVisible(true);
    };

    window.addEventListener('mousemove', mouseMove);
    document.addEventListener('mouseleave', mouseLeave);
    document.addEventListener('mouseenter', mouseEnter);

    const handleLinkHover = (e: Event) => {
      const target = e.currentTarget as HTMLElement;
      setCursorVariant('hover');
      
      // Check if it's a button with specific text
      if (target.tagName === 'BUTTON') {
        setCursorText('Click');
      } else if (target.tagName === 'A') {
        setCursorText('View');
      }
    };

    const handleLinkLeave = () => {
      setCursorVariant('default');
      setCursorText('');
    };

    const links = document.querySelectorAll('a, button');
    links.forEach(link => {
      link.addEventListener('mouseenter', handleLinkHover);
      link.addEventListener('mouseleave', handleLinkLeave);
    });

    // Project cards hover effect
    const projectCards = document.querySelectorAll('.project-card');
    projectCards.forEach(card => {
      card.addEventListener('mouseenter', () => {
        setCursorVariant('project');
        setCursorText('View Project');
      });
      card.addEventListener('mouseleave', () => {
        setCursorVariant('default');
        setCursorText('');
      });
    });

    return () => {
      window.removeEventListener('mousemove', mouseMove);
      document.removeEventListener('mouseleave', mouseLeave);
      document.removeEventListener('mouseenter', mouseEnter);
      
      links.forEach(link => {
        link.removeEventListener('mouseenter', handleLinkHover);
        link.removeEventListener('mouseleave', handleLinkLeave);
      });
      
      projectCards.forEach(card => {
        card.removeEventListener('mouseenter', () => {});
        card.removeEventListener('mouseleave', () => {});
      });
    };
  }, [isVisible]);

  const variants = {
    default: {
      x: mousePosition.x - 16,
      y: mousePosition.y - 16,
      height: 32,
      width: 32,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      mixBlendMode: 'difference' as const,
      fontSize: '0px',
      color: 'rgba(255, 255, 255, 0)'
    },
    hover: {
      x: mousePosition.x - 40,
      y: mousePosition.y - 40,
      height: 80,
      width: 80,
      backgroundColor: 'rgba(255, 92, 0, 0.8)',
      mixBlendMode: 'difference' as const,
      fontSize: '14px',
      color: 'rgba(255, 255, 255, 1)'
    },
    project: {
      x: mousePosition.x - 60,
      y: mousePosition.y - 60,
      height: 120,
      width: 120,
      backgroundColor: 'rgba(255, 92, 0, 0.8)',
      mixBlendMode: 'difference' as const,
      fontSize: '16px',
      color: 'rgba(255, 255, 255, 1)'
    }
  };

  return (
    <motion.div
      className="cursor fixed top-0 left-0 rounded-full pointer-events-none z-50 hidden md:flex items-center justify-center font-medium"
      variants={variants}
      animate={cursorVariant}
      initial={{ opacity: 0 }}
      style={{ opacity: isVisible ? 1 : 0 }}
      transition={{
        type: 'spring',
        damping: 25,
        stiffness: 300,
        mass: 0.5
      }}
    >
      {cursorText}
    </motion.div>
  );
};

export default Cursor;