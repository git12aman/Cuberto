import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const services = [
  {
    id: 1,
    title: "Web Design",
    description: "We create beautiful, intuitive websites that drive user engagement and business growth.",
    icon: "🎨"
  },
  {
    id: 2,
    title: "Mobile Apps",
    description: "Native and cross-platform mobile applications that deliver exceptional user experiences.",
    icon: "📱"
  },
  {
    id: 3,
    title: "UX/UI Design",
    description: "User-centered design solutions that enhance usability and drive conversion.",
    icon: "✏️"
  },
  {
    id: 4,
    title: "Branding",
    description: "Strategic brand development that communicates your unique value proposition.",
    icon: "🏆"
  }
];

const ServiceCard = ({ service, index }: { service: typeof services[0], index: number }) => {
  return (
    <motion.div
      variants={{
        hidden: { y: 50, opacity: 0 },
        visible: {
          y: 0,
          opacity: 1,
          transition: {
            duration: 0.8,
            ease: "easeOut"
          }
        }
      }}
      whileHover={{ 
        y: -15, 
        transition: { duration: 0.3 },
        boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)"
      }}
      className="bg-white rounded-lg overflow-hidden transform transition-all duration-300 group"
    >
      <div className="h-full flex flex-col">
        <div className="p-8 flex-grow">
          <motion.div 
            className="text-5xl mb-6 transform transition-all duration-300 group-hover:scale-110"
            animate={{ rotate: [0, 5, 0, -5, 0] }}
            transition={{ 
              repeat: Infinity, 
              repeatDelay: 3,
              duration: 1.5 
            }}
          >
            {service.icon}
          </motion.div>
          
          <h3 className="text-xl font-bold mb-3 group-hover:text-accent transition-colors duration-300">
            {service.title}
          </h3>
          
          <p className="text-gray-600">
            {service.description}
          </p>
        </div>
        
        <motion.div 
          className="bg-black text-white py-4 px-6 text-center transform translate-y-full group-hover:translate-y-0 transition-transform duration-300"
          whileHover={{ backgroundColor: "#ff5c00" }}
        >
          <span className="font-medium">Learn More</span>
        </motion.div>
      </div>
    </motion.div>
  );
};

const Services = () => {
  const containerRef = useRef(null);
  const isInView = useInView(containerRef, { once: false, amount: 0.2 });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3
      }
    }
  };

  return (
    <section className="py-20 px-6 md:px-12 bg-white">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true, amount: 0.3 }}
          className="mb-16 text-center"
        >
          <h2 className="text-3xl md:text-5xl font-bold mb-6">Our Services</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            We offer a comprehensive range of digital services to help your business thrive in the digital landscape.
          </p>
        </motion.div>

        <motion.div
          ref={containerRef}
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {services.map((service, index) => (
            <ServiceCard key={service.id} service={service} index={index} />
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Services;