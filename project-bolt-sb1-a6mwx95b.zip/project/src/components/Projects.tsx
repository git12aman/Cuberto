import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';

const projects = [
  {
    id: 1,
    title: "Fintech Revolution",
    category: "Web Design",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
  },
  {
    id: 2,
    title: "Luxury Redefined",
    category: "Branding",
    image: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2053&q=80"
  },
  {
    id: 3,
    title: "Eco Marketplace",
    category: "Mobile App",
    image: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
  }
];

const ProjectCard = ({ project, index }: { project: typeof projects[0], index: number }) => {
  const cardRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: cardRef,
    offset: ["start end", "end start"]
  });

  const y = useTransform(
    scrollYProgress, 
    [0, 1], 
    [100, -100]
  );

  const opacity = useTransform(
    scrollYProgress,
    [0, 0.2, 0.8, 1],
    [0, 1, 1, 0]
  );

  const scale = useTransform(
    scrollYProgress,
    [0, 0.2, 0.8, 1],
    [0.8, 1, 1, 0.8]
  );

  return (
    <motion.div
      ref={cardRef}
      style={{ y, opacity, scale }}
      className="mb-32 relative"
      initial={{ opacity: 0, y: 100 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay: index * 0.2 }}
      viewport={{ once: true, amount: 0.3 }}
    >
      <motion.div 
        className="relative overflow-hidden rounded-lg group cursor-pointer"
        whileHover={{ 
          scale: 0.98,
          boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)"
        }}
        transition={{ 
          duration: 0.5,
          ease: "easeOut"
        }}
      >
        <div className="aspect-w-16 aspect-h-9 overflow-hidden">
          <motion.img 
            src={project.image} 
            alt={project.title} 
            className="w-full h-[500px] object-cover"
            whileHover={{ 
              scale: 1.1,
              transition: { duration: 0.8 }
            }}
          />
        </div>
        <motion.div 
          className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500 flex items-center justify-center"
          initial={{ opacity: 0 }}
          whileHover={{ opacity: 1 }}
        >
          <motion.div 
            className="text-center text-white p-6"
            initial={{ y: 50, opacity: 0 }}
            whileHover={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <motion.div 
              className="text-sm uppercase tracking-wider mb-2"
              initial={{ y: 20, opacity: 0 }}
              whileHover={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.2 }}
            >
              {project.category}
            </motion.div>
            <motion.h3 
              className="text-2xl md:text-3xl font-bold mb-4"
              initial={{ y: 20, opacity: 0 }}
              whileHover={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.3 }}
            >
              {project.title}
            </motion.h3>
            <motion.div 
              className="mt-4 inline-block overflow-hidden"
              initial={{ width: 0 }}
              whileHover={{ width: "auto" }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <motion.button 
                className="px-8 py-3 border-2 border-white rounded-full hover:bg-white hover:text-black transition-colors duration-300"
                whileHover={{ 
                  scale: 1.05,
                  backgroundColor: "#ffffff",
                  color: "#000000"
                }}
                whileTap={{ scale: 0.95 }}
              >
                View Project
              </motion.button>
            </motion.div>
          </motion.div>
        </motion.div>
        
        {/* Card corner accents */}
        <motion.div 
          className="absolute top-4 left-4 w-10 h-10 border-t-2 border-l-2 border-white opacity-0 group-hover:opacity-100"
          initial={{ x: -10, y: -10, opacity: 0 }}
          whileHover={{ x: 0, y: 0, opacity: 1 }}
          transition={{ duration: 0.3, delay: 0.1 }}
        />
        <motion.div 
          className="absolute top-4 right-4 w-10 h-10 border-t-2 border-r-2 border-white opacity-0 group-hover:opacity-100"
          initial={{ x: 10, y: -10, opacity: 0 }}
          whileHover={{ x: 0, y: 0, opacity: 1 }}
          transition={{ duration: 0.3, delay: 0.2 }}
        />
        <motion.div 
          className="absolute bottom-4 left-4 w-10 h-10 border-b-2 border-l-2 border-white opacity-0 group-hover:opacity-100"
          initial={{ x: -10, y: 10, opacity: 0 }}
          whileHover={{ x: 0, y: 0, opacity: 1 }}
          transition={{ duration: 0.3, delay: 0.3 }}
        />
        <motion.div 
          className="absolute bottom-4 right-4 w-10 h-10 border-b-2 border-r-2 border-white opacity-0 group-hover:opacity-100"
          initial={{ x: 10, y: 10, opacity: 0 }}
          whileHover={{ x: 0, y: 0, opacity: 1 }}
          transition={{ duration: 0.3, delay: 0.4 }}
        />
      </motion.div>
    </motion.div>
  );
};

const Projects = () => {
  return (
    <section className="py-20 px-6 md:px-12 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true, amount: 0.3 }}
          className="mb-16 text-center"
        >
          <h2 className="text-3xl md:text-5xl font-bold mb-6">Featured Projects</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            A selection of our award-winning work that showcases our expertise and creativity.
          </p>
        </motion.div>

        <div className="space-y-12">
          {projects.map((project, index) => (
            <ProjectCard key={project.id} project={project} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;